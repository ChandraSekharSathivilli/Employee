package bunny.examly;

	class Employee {
		int Id;
		String name;
		String salary;
		String departmant;

		public Employee(int id, String name, String salary, String departmant) {
			super();
			Id = id;
			this.name = name;
			this.salary = salary;
			this.departmant = departmant;
		}

		@Override
		public String toString() {
			return "Employee [Id=" + Id + ", name=" + name + ", salary=" + salary + ", departmant=" + departmant + "]";
		}
	}

	

