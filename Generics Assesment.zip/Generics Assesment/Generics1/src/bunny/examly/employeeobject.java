package bunny.examly;

import java.util.HashSet;

public class employeeobject {
		public static void main(String[] args) {
			HashSet<Employee> hSet = new HashSet<Employee>();
			hSet.add(new Employee(1, "name1", "25000", "dept1"));
			hSet.add(new Employee(2, "name2", "23000", "dept2"));
			hSet.add(new Employee(3, "name3", "20000", "dept3"));	
			for(Employee e : hSet) {
				System.out.println(e);
			}
		}
	}
