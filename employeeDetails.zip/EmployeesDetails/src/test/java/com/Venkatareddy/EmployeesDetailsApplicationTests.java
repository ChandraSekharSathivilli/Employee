package com.Venkatareddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
