package Q2;

public class Employee {
	int basic = 20000;
public void total_salary() {
	System.out.println("");
}
}
