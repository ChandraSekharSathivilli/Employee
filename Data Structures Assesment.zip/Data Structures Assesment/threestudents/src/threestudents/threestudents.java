package threestudents;

import java.util.ArrayList;
import java.util.Scanner;

public class threestudents {
	public static void main(String[] args) 
	{
		int s1,s2,s3,total,avg;
		Scanner sc = new Scanner(System.in);
		  
		  System.out.println("Enter the number of students");
		  int n = sc.nextInt();
		  ArrayList<Student> arr=new ArrayList<>();
		  for(int i=1;i<=n;i++) {
			  System.out.println("Enter the marks for student : "+i);
			  System.out.println("Enter the subject 1 marks");
			  s1=sc.nextInt();
			  System.out.println("Enter the subject 2 marks");
			  s2=sc.nextInt();
			  System.out.println("Enter the subject 3 marks");
			  s3=sc.nextInt();
			  total = s1+s2+s3;
			  avg=total/3;
			  System.out.println("Total marks for student "+i+" = "+total);
			  System.out.println("avg marks for student "+i+" = "+avg);
			  Student obj=new Student(s1, s2, s3); 
			  arr.add(obj);
		  }
		  int totalScoreinSub1=0;
		  for(Student sub1:arr) {
			  totalScoreinSub1=totalScoreinSub1+sub1.a;
		  }
		  System.out.println("Total score in subject 1 :"+totalScoreinSub1);
		  System.out.println("Average Score in subject 1 :"+totalScoreinSub1/3);
		  
		  int totalScoreinSub2=0;
		  for(Student sub1:arr) {
			  totalScoreinSub2=totalScoreinSub2+sub1.b;
		  }
		  System.out.println("Total score in subject 2 :"+totalScoreinSub2);
		  System.out.println("Average Score in subject 2 :"+totalScoreinSub2/3);
		  
		  int totalScoreinSub3=0;
		  for(Student sub1:arr) {
			  totalScoreinSub3=totalScoreinSub3+sub1.b;
		  }
		  System.out.println("Total score in subject 3 :"+totalScoreinSub3);
		  System.out.println("Average Score in subject 3 :"+totalScoreinSub3/3);	  
		  
}
	}
class Student{
	int a;
	int b;
	int c;
	public Student(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;

}
}
